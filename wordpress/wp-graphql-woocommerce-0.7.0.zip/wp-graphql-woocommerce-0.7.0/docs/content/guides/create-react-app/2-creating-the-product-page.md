---
title: "2. Creating the Product Page"
metaTitle: "CRA WooGraphQL Product Page Tutorial | WooGraphQL Docs | AxisTaylor"
metaDescription: "A tutorial on implementing a product page in with WooGraphQL + Apollo + React."
---

# Coming Soon

Sorry, this section is still under development :construction:.